---
title: "News Post 7"
date: 2022-03-18T11:10:36+08:00
draft: false
language: en
featured_image: ../assets/images/featured/featured-img-placeholder.png
summary: Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed cursus, odio nec venenatis lacinia, lacus lectus varius nisi, in tristique mi purus ut libero.
description: Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed cursus, odio nec venenatis lacinia, lacus lectus varius nisi, in tristique mi purus ut libero. Vestibulum vel convallis felis. Ut finibus lorem vestibulum lobortis rhoncus.
author: TailBliss
authorimage: ../assets/images/global/author.webp
categories: News
tags: news
---

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed cursus, odio nec venenatis lacinia, lacus lectus varius nisi, in tristique mi purus ut libero. <!--more--> Vestibulum vel convallis felis. Ut finibus lorem vestibulum lobortis rhoncus. Sed mi tellus, volutpat aliquam enim sed, efficitur cursus lacus. Nunc congue, justo luctus vehicula finibus, tortor justo consectetur ligula, at lobortis nisl ipsum eu mauris. Fusce finibus mi in enim mollis dapibus. In non leo et mi pharetra vehicula vel ut felis. Nam eros metus, tristique a tellus vitae, aliquet posuere turpis. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Pellentesque non molestie orci, id scelerisque odio. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Suspendisse pharetra rhoncus massa, eu sagittis purus consectetur eget.

Duis vitae consectetur dolor. Sed consectetur nibh ligula, vitae eleifend velit vulputate non. Nam eleifend, tellus ut commodo hendrerit, leo erat dictum est, non faucibus sapien mauris eu sapien. Sed et tortor sit amet ex rhoncus sagittis. Vestibulum pretium nisl non sodales congue. Ut sit amet iaculis felis. Nulla tristique tristique posuere.

Sed neque ex, euismod vel leo vitae, ornare elementum neque. Ut laoreet metus nec ex euismod mattis. Vivamus dapibus suscipit risus nec gravida. Mauris est odio, maximus eget sem eu, rhoncus tincidunt ipsum. Proin laoreet maximus dolor, in euismod purus suscipit et. Praesent eleifend mi sed massa pulvinar dictum. Curabitur leo lorem, pharetra sit amet orci in, maximus cursus purus. Integer finibus massa tincidunt orci gravida mattis. Praesent nec orci libero. Suspendisse vel magna posuere libero ultricies lacinia.

Pellentesque at feugiat arcu, at tincidunt est. Sed vel urna congue, porta dui sed, lacinia velit. Nulla porta vehicula sem, id porta sem suscipit id. Ut faucibus erat ac odio tempus molestie at a nisi. Pellentesque id ornare ipsum, a vestibulum nisi. Nullam id felis nec dolor tincidunt viverra quis ac tortor. Maecenas id viverra tellus, eu egestas tellus. Integer feugiat et arcu sit amet venenatis. Nam posuere mi quis justo rhoncus, nec cursus quam venenatis. Duis sapien ante, egestas sit amet nulla sit amet, facilisis lobortis lectus. Nullam non arcu pretium, pretium ligula in, sagittis nibh. Aenean egestas eget ipsum tempus feugiat.

Aliquam tortor erat, elementum a neque et, ultricies mollis nunc. Etiam bibendum eu magna ut commodo. Curabitur gravida lorem nec ultrices blandit. Nam egestas est a purus porttitor cursus. Suspendisse dapibus scelerisque odio facilisis porta. Curabitur urna felis, vehicula eget aliquam ut, elementum ac est. Vestibulum posuere nulla nunc, ut condimentum turpis imperdiet sit amet.